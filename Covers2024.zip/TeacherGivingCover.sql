Create View TeacherGivingCover As
Select TeacherGivingCover, Count(TeacherGivingCover) As Hours from Covers Group By TeacherGivingCover Order By Count(TeacherGivingCover) Desc;

