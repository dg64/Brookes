CREATE VIEW ViewCovers As
select DateCover, strftime('%Y', DateCover) As YearCover, strftime('%m', DateCover) As MonthCover, strftime('%d', DateCover) As DayCover,
	IIF(strftime('%w', DateCover) = '1', 'Monday', IIF(strftime('%w', DateCover) = '2', 'Tuesday', IIF(strftime('%w', DateCover) = '3', 'Wednesday', IIF(strftime('%w', DateCover) = '4', 'Thursday', IIF(strftime('%w', DateCover) = '5', 'Friday', IIF(strftime('%w', DateCover) = '6', 'Saturday', 'Sunday')))))) As DayOfWeekCover, strftime('%W', DateCover) As WeekCover, Period, TeacherAskingCover, TeacherGivingCover
From Covers
Order By DateCover, Period, TeacherAskingCover;
