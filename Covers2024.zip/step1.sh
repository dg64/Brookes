
#!/bin/bash

sed '1d' input.csv >step1.csv
sed '/Service/d' step1.csv >step2.csv
cut -d, -f1,2,3,4,5,6,8 step2.csv >step3.csv
sed '1d' step3.csv >step4.csv

