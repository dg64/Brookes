CREATE VIEW TopListFriday As
Select TeacherAskingCover, Count(TeacherAskingCover) As Counter From (

Select DateCover, TeacherAskingCover from ViewCovers Where DayOfWeekCover = 'Friday' Group By DateCover, TeacherAskingCover Order By TeacherAskingCover, DateCover)

Group By TeacherAskingCover Order By Count(TeacherAskingCover) desc;
